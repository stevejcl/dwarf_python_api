var $protobuf = protobuf;

export default $protobuf;