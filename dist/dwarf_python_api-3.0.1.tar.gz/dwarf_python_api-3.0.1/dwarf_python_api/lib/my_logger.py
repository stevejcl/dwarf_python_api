# import data for config.py
import logging
import types
import os
import sys
import shutil
# import data for config.py
import dwarf_python_api.get_config_data

# Define logger instance and initial variables
logger = logging.getLogger('my_logger')
file_handler = None  # Initialize file_handler as None
log_file = None  # Initialize log_file as None

# Define custom NOTICE and SUCCESS logging level
NOTICE_LEVEL_NUM = 22
SUCCESS_LEVEL_NUM = 25

# Custom success logging method
def notice(self, message, *args, **kwargs):
    if self.isEnabledFor(NOTICE_LEVEL_NUM):
        # We must pass args explicitly as a tuple to avoid the missing argument error
        self._log(NOTICE_LEVEL_NUM, message, args, **kwargs)

logging.Logger.notice = notice  # Add notice method to logger class

def success(self, message, *args, **kwargs):
    if self.isEnabledFor(SUCCESS_LEVEL_NUM):
        # We must pass args explicitly as a tuple to avoid the missing argument error
        self._log(SUCCESS_LEVEL_NUM, message, args, **kwargs)

logging.Logger.success = success  # Add success method to logger class

# --- Shared-log thread exclusion (additive, multi-Dwarf support) -----------
# A caller (e.g. the UI) that has already given a specific thread its own
# dedicated, filtered log handler can register that thread here so the
# shared/global file_handler below stops ALSO capturing its output. This
# module stays UI-agnostic - it just tracks thread idents to skip, with no
# knowledge of what "scheduler" or "session" means.
_shared_log_excluded_threads = set()


def exclude_thread_from_shared_log(thread_ident):
    """Stop the shared/global log file (update_log_file()'s file_handler)
    from also capturing this thread's records - use once that thread has
    its own dedicated handler, to avoid duplicate/cross-contaminated
    entries when multiple threads log concurrently."""
    _shared_log_excluded_threads.add(thread_ident)


def include_thread_in_shared_log(thread_ident):
    """Undo exclude_thread_from_shared_log() once the thread's own
    dedicated handler is no longer in use (e.g. it has stopped)."""
    _shared_log_excluded_threads.discard(thread_ident)


class _SharedLogThreadFilter(logging.Filter):
    """Attached to the shared/global file_handler - drops records from any
    thread that has registered its own dedicated handler via
    exclude_thread_from_shared_log(), so the shared file doesn't also pick
    up a copy of output that's already fully captured elsewhere."""
    def filter(self, record):
        return record.thread not in _shared_log_excluded_threads


# --- Per-thread device tagging (additive, multi-Dwarf support) -------------
# Most low-level protocol log lines (receive_messages, ping/pong, frame
# decoding...) live deep inside WebSocketClient's async methods, which
# don't have a dwarf_uid string handy to embed in an f-string by hand -
# there are hundreds of call sites, so editing each one isn't practical.
# What they DO all share is the THREAD they run on: session.event_loop_
# thread, one persistent background thread per physical Dwarf (see
# dwarf_session_socket.py's init_socket()). Registering that thread's
# ident here tags every record it produces with the device label, so a
# SHARED log file can still be told apart per device with a simple grep/
# search - without needing separate log files (see
# exclude_thread_from_shared_log() above for that alternative).
_thread_device_labels: dict[int, str] = {}


def register_thread_device_label(thread_ident, label):
    """Tag every future log record from this thread with `label`
    (typically a dwarf_uid). Call this once you know which physical
    device a given thread belongs to - e.g. right after a session's
    event_loop_thread is created/confirmed alive."""
    _thread_device_labels[thread_ident] = label


def unregister_thread_device_label(thread_ident):
    """Undo register_thread_device_label() once that thread has stopped
    (e.g. after a disconnect) so a later, unrelated thread that happens
    to reuse the same ident doesn't inherit a stale label."""
    _thread_device_labels.pop(thread_ident, None)


class _DeviceLabelFilter(logging.Filter):
    """Attaches a `device` attribute to every record (used by the format
    strings below as %(device)s) - "[label] " for a thread registered via
    register_thread_device_label(), or "" otherwise. Always returns True:
    this filter only annotates records, it never drops any (that's
    _SharedLogThreadFilter's job, on the file handler specifically)."""
    def filter(self, record):
        label = _thread_device_labels.get(record.thread)
        record.device = f"[{label}] " if label else ""
        return True

# Function to update or create the log file handler
def update_log_file(default_name: str = "app.log"):
    """
    Dynamically update or create the log file handler.

    `default_name`: this is a GENERIC library, reused by several
    standalone tools (main_v3.py, get_live_data_dwarf.py, ...) besides
    astro_dwarf_ui - it has no business hardcoding any ONE application's
    own naming convention. "app.log" is a neutral library-level default,
    used only when no config.py value is present at all AND the caller
    hasn't specified its own preference. An APPLICATION that wants a
    specific name (e.g. astro_dwarf_ui wanting "astro_session.log")
    should pass its own default_name explicitly - see astro_dwarf_ui.py's
    own startup call - rather than this library assuming any one app's
    convention for everyone (user-corrected Sep 2026: an earlier version
    of this fix hardcoded "astro_session.log" directly in here, which
    is exactly the kind of app-specific detail a generic library
    shouldn't own).
    """
    global log_file  # To update the global variable
    global file_handler  # To reference the existing file handler

    # Reload configuration data
    data_config = dwarf_python_api.get_config_data.get_config_data()

    # Determine the new log file
    # BUG FIX (user-reported Sep 2026): when no config.py is found at
    # all, get_config_data() falls back to log_file=None (a genuinely
    # MISSING value), not "" (an empty-but-present value) - the ""
    # check below correctly defaults THAT case to a real filename, but
    # None fell through to the final else, silently setting
    # new_log_file to None too, which the later `if log_file is not
    # None:` guard reads as "logging explicitly disabled" (the SAME as
    # data_config['log_file'] == "False") - conflating "no config file
    # present at all" with "user explicitly turned logging off" and
    # skipping file creation entirely, with no error/warning to explain
    # why. Both "" and None (not just "") now fall back to default_name.
    #
    # Follow-up (Sep 2026, user-reported): this whole function is
    # process-wide, not per-device - get_config_data() with no
    # explicit path looks for a single root-level config.py, which
    # doesn't exist in the multi-device layout (each device has its
    # own config_<slug>.py/.ini instead - see pages/pairing.py). That's
    # not a bug to fix here though: pages/logs.py's own module
    # docstring confirms the INTENDED design is one shared log file for
    # the whole process (every line already tagged with a "[dwarf_uid]"
    # prefix), not one file per device - so this function correctly has
    # no device-specific config to read, regardless of how many devices
    # are paired. What name that ONE shared file gets, absent a config.py
    # override, is the CALLER's choice (default_name), not this
    # library's to assume - see this function's own docstring.
    if data_config['log_file'] == "False":
        new_log_file = None
    elif not data_config['log_file']:  # "" or None
        new_log_file = default_name
    else:
        new_log_file = data_config['log_file']

    # Check if the log file has changed
    if new_log_file != log_file:
        log_file = new_log_file

        # Remove the existing file handler if it exists
        if file_handler and file_handler in logger.handlers:
            logger.removeHandler(file_handler)
            file_handler.close()  # Close the old file handler

        # Add the new file handler if log_file is not None
        if log_file is not None:
            try:
                # Backup old log file if it exists
                old_log_file = log_file + '.old'
                if os.path.exists(log_file):
                    try:
                        # Rename the old log file to app.log.old (or any other naming convention)
                        shutil.move(log_file, old_log_file)
                    except Exception as e:
                        print(f"Error moving log file: {e}")

                # Determine file log level based on 'debug' in data_config
                file_log_level = logging.DEBUG if data_config.get('debug') else logging.INFO
                print(f"file_log_level: {file_log_level}")

                file_handler = logging.FileHandler(log_file)
                file_handler.setLevel(file_log_level)
                file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(device)s%(message)s'))
                file_handler.addFilter(_SharedLogThreadFilter())
                logger.addHandler(file_handler)
                logger.notice(f"Log file updated to: {log_file}")
            except Exception as e:
                logger.error(f"Failed to update log file: {e}")
        else:
            logger.info("Log file disabled.")

# Initial logger setup
def setup_logger():
    """
    Initialize the logger and configure handlers.
    """
    global logger

    # Set logger level to NOTSET, allowing handlers to filter logs
    logging.getLogger().setLevel(logging.NOTSET)  # Allow handlers to manage levels independently

    # Reload configuration data
    data_config = dwarf_python_api.get_config_data.get_config_data()

    # Set root logger level
    root_level = logging.DEBUG if data_config.get('debug') else logging.INFO
    logger.setLevel(root_level)
    print(f"root_level: {root_level}")

    # Add console logging handler separately
    console_handler = logging.StreamHandler()
    console_handle_level = logging.INFO if data_config.get('trace') else NOTICE_LEVEL_NUM
    if data_config['log_file'] == "False":
        console_handle_level = logging.DEBUG if data_config.get('debug') else logging.INFO

    console_handler.setLevel(console_handle_level)
    console_handler.setFormatter(logging.Formatter('%(device)s%(message)s'))
    logger.addHandler(console_handler)

    # Add custom log levels
    logging.addLevelName(NOTICE_LEVEL_NUM, 'NOTICE')
    logging.addLevelName(SUCCESS_LEVEL_NUM, 'SUCCESS')

    # Bind custom log methods to the logger
    logger.notice = types.MethodType(notice, logger)
    logger.success = types.MethodType(success, logger)

    # Tags every record with its device label (see
    # register_thread_device_label() above) before ANY handler sees it -
    # added once, here, rather than per-handler, so console and file
    # output both benefit without duplicating the filter.
    logger.addFilter(_DeviceLabelFilter())

    # Configure the log file handler using `update_log_file`
    update_log_file()

# Call the setup_logger function when the module is imported
setup_logger()

def debug(*messages):
    for message in messages:
        logger.debug(message) 

def error(*messages):
    for message in messages:
        logger.error(message) 

def warning(*messages):
    for message in messages:
        logger.warning(message) 

def info(*messages):
    for message in messages:
        logger.info(message) 

def notice(*messages):
    for message in messages:
        logger.notice(message)

def success(*messages):
    for message in messages:
        logger.success(message)